## Run multilogistic model

This example provides instructions to run multilogistic model.
1. Open sfp_multilogistic.m and change variable mainroot to the directory of the repository
2. Run sfp_decoding.m

It should produce results similar to the logistic.fig
Results may very slightly differ because of stochasticity and noise.
perl filterp.pl americas
perl filterp.pl africa
perl filterp.pl eurasia
perl filterp.pl sahul

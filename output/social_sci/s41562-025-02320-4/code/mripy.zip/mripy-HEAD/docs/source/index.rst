.. mripy documentation master file, created by
   sphinx-quickstart on Tue Oct 12 15:11:10 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to mripy's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   install
   mripy
   glm
   modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

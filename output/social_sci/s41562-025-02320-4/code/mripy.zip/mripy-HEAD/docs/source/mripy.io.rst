mripy.io package
================

Submodules
----------

mripy.io.freesurfer module
--------------------------

.. automodule:: mripy.io.freesurfer
   :members:
   :undoc-members:
   :show-inheritance:

mripy.io.gifti module
---------------------

.. automodule:: mripy.io.gifti
   :members:
   :undoc-members:
   :show-inheritance:

mripy.io.niml module
--------------------

.. automodule:: mripy.io.niml
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: mripy.io
   :members:
   :undoc-members:
   :show-inheritance:

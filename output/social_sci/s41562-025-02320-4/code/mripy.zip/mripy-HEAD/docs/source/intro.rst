Introduction
============
``mripy`` is a collection of handy small tools for analyzing neuroimaging data (esp. high resolution fMRI), 
which can be used both as a Python package and a set of command line tools. It is a useful augmentation 
to the AFNI tool chain.
mripy.tests package
===================

Submodules
----------

mripy.tests.context module
--------------------------

.. automodule:: mripy.tests.context
   :members:
   :undoc-members:
   :show-inheritance:

mripy.tests.test\_afni module
-----------------------------

.. automodule:: mripy.tests.test_afni
   :members:
   :undoc-members:
   :show-inheritance:

mripy.tests.test\_io module
---------------------------

.. automodule:: mripy.tests.test_io
   :members:
   :undoc-members:
   :show-inheritance:

mripy.tests.test\_timecourse module
-----------------------------------

.. automodule:: mripy.tests.test_timecourse
   :members:
   :undoc-members:
   :show-inheritance:

mripy.tests.test\_utils module
------------------------------

.. automodule:: mripy.tests.test_utils
   :members:
   :undoc-members:
   :show-inheritance:

mripy.tests.test\_utils\_slow module
------------------------------------

.. automodule:: mripy.tests.test_utils_slow
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: mripy.tests
   :members:
   :undoc-members:
   :show-inheritance:

function min_max = mripy_range(A)
%MRIPY_RANGE Find the smallest and largest element in array.
%   2017-08-14: Created by qcc
    min_max = [min(A(:)), max(A(:))];
end


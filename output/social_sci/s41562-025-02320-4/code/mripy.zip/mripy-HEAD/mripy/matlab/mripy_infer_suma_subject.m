function subject = mripy_infer_suma_subject(suma_dir)
%MRIPY_INFER_SUMA_SUBJECT Infer subject identifier for the suma dir.
%   2017-08-13: Created by qcc
    error('NotImplemented!');
end


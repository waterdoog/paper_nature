#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function, division, absolute_import, unicode_literals
from pylab import * 


def pylab_eval(expr, **variables):
    return eval(expr, None, variables)


if __name__ == '__main__':
    pass

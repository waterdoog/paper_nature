function main_figures

close all;

% figure 1
sim_power_analysis();

% figure 2
review_run();

% figure 3
ffx_null_outlier_modest();

% Exteded data figure 1
review_run_effectsize();

end